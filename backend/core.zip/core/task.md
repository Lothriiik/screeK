# Tasks — screeK Backend (Guia de Estudo Go)

Ordenado pedagogicamente. Cada task ensina um conceito novo.
Consulte os arquivos `backend/fluxo_*.md` como referência dos requisitos de negócio.

> **🧩 Mini Atividades**: Cada task agora tem um exercício isolado para você praticar o conceito antes de aplicar no screeK. Peça mais detalhes sobre qualquer uma!

---

## 🟢 Fase 1 · Fundamentos & Estrutura Clean

- [x] **T01** — Revisar e testar CRUD de Users
- [x] **T02** — Criar `GET /users/search?q=`
- [x] **T03** — Definir interfaces nos stores
- [x] **T04** — Separar bootstrap: `main.go` + `app.go`
- [x] **T05** — Criar struct `Config` centralizada
- [x] **T06** — Criar DTOs e Motor de Validação Avançado
- [x] Exportar schema consolidado para `migrations/01_initial_schema.sql`.
- [x] Remover chamadas de `AutoMigrate` do `app.go`.
- [x] Corrigir vulnerabilidade latente de SQL Injection em Analytics.
- [x] Implementar ordenação cronológica em `GetMovieSessionsGroupedByCinema`.

---

## 🟡 Fase 2 · Segurança (Hashing + JWT + Middleware)

- [x] **T07** — Criar funções Bcrypt
- [x] **T08** — Atualizar `CreateUser` pra salvar senha hasheada
- [x] **T09** — Criar módulo Auth com service JWT
- [x] **T10** — Criar `POST /auth/login`
- [x] **T11** — Criar Middleware Chi de autenticação JWT
- [x] **T12** — Proteger rotas com JWT
- [x] **T13** — Criar `POST /users/register` e aplicar Validação
- [x] **T14** — Criar `PUT /auth/change-password`
- [x] **T15** — Criar `DELETE /users/me`
- [x] **T16** — Criar rotas auxiliares de Auth (Logout, Forgot Password e CORS com Redis)

---

## 🟠 Fase 3 · Domínio de Filmes (API Externa)

- [x] **T17** — Revisar rotas de filmes existentes
- [x] **T18** — Criar `GET /people/{id}` e `GET /people/{id}/movies`
- [x] **T19** — Criar `GET /movies/{id}/recommendations`

---

## 🔴 Fase 4 · Motor de Compras & Concorrência (Bookings + Redis)

- [x] **T20** — Adicionar `SessionType` e Suporte a Sessões Gratuitas/Abertas
- [x] **T20.5** — Implementar Enums e Cargos (RBAC)
- [x] **T20.6** — Relação de Gestão (Manager <-> Cinema)
- [x] **T21** — Criar `GET /movies/playing?city=&date=`
- [x] **T22** — Criar `GET /movies/{id}/sessions?city=&date=`
- [x] **T23** — Criar `GET /sessions/{id}/seats`
- [x] **T24** — Configurar Redis
- [x] **T25** — Criar `POST /tickets/reserve` com Lock Redis
- [x] **T26** — Criar mock `POST /transactions/{id}/pay` (com Context Propagation)
- [x] **T27** — Criar `POST /tickets/{id}/cancel`
- [x] **T28** — Criar endpoints informacionais de Booking
- [x] **T29** — ⚡ Teste de concorrência
- [x] **T29.5** — 🕰️ CRON Job: Garbage Collector de Ingressos (Locks Expirados)

---

## 🟣 Fase 5 · Social & O Feed Polimórfico

- [x] **T30** — Criar atividade do User (O Diário Privado)
- [x] **T31** — A Tabela Suprema (Posts Core)
- [x] **T32** — Reviews e Session Shares (Tipos Dinâmicos)
- [x] **T33** — O Feed Universal
- [x] **T34** — Sistema de Respostas (Replies)
- [x] **T35** — Toggle Universal (Likes)
- [x] **T36** — O Sistema de Follow

---

## 💳 Fase 6 · Integrações Externas (Pagamento & Email)

- [x] **T37** — Criar interface `PaymentStrategy`
- [x] **T38** — Configurar Stripe (Sandbox)
- [x] **T39** — Implementar Idempotency-Key no pagamento
- [x] Implementar bypass de `RoleAdmin` no `ManagementService`.
- [x] Padronizar rotas sob `/admin/management/*`.
- [x] Corrigir lógica de exclusão de sessão (ignorar tickets `CANCELLED`).
- [x] Ajustar testes unitários para as novas assinaturas de método.
- [x] **T40** — Criar Webhook handler da Stripe
- [x] **T41** — Configurar Resend (Email transacional)
- [x] **T42** — Integrar envios de Email nos fluxos (Pós-Pagamento e Tickets)
- [x] **T43** — Modularização de Pagamento (Clean Architecture)
  - Extrair lógica para `internal/payment`, tornando bookings agnóstico ao Stripe.

---

- [x] **T64** — Estratégia de Performance: Índices no PostgreSQL 🌟
    - Mapear as tabelas mais acessadas (`tickets`, `posts`) e descrever por que removemos os scans sequenciais com índices B-Tree.
    - Aplicar as GORM Tags nos models para automatizar a criação em produção.
    - *Aprende:* Estratégias de indexação e como evitar Sequential Scans em sistemas de alta carga.

- [ ] **T65** — Polimento Final e README Técnico
    - Consolidar links para o Swagger e instruções claras de `docker-compose`.
    - *Aprende:* UX para outros desenvolvedores (DX).

- [ ] **T65** — Polimento Final e README Técnico
  - Consolidar links para o Swagger e instruções claras de `docker-compose`.
  - *Aprende:* UX para outros desenvolvedores (DX).

---

## 🔒 Fase 8 · Hardening & Observabilidade

- [ ] **T56** — Implementar Graceful Shutdown no `app.go`
- [ ] **T57** — Adicionar Rate Limiting
- [ ] **T58** — Logging Estruturado (`slog`)
- [ ] **T59** — Circuit Breaker no `TMDBClient`
- [ ] **T60** — Database Indexing (A aplicação real no Banco)
- [x] **T60.5** — Migrar IDs Sensíveis para UUID (Concluído)
- [ ] **T68** — Implementar Refresh Tokens (JWT) vinculados a persistência (Redis/DB)

---

## ⚫ Fase 9 · Notificações & Jobs

- [ ] **T43** — Notificações & EventBus (Observer Pattern)
  - [ ] **T69**: Criar um EventBus interno simples para comunicação entre módulos (ex: pós-venda -> feed social).
- [ ] **T44** — Listener de Notificações
- [ ] **T45** — CRON Job: Watchlist × Sessões

---

## 🐳 Fase 10 · Infraestrutura & DevOps

- [ ] **T51** — Configurar ferramenta Golang Migrate (`golang-migrate`)
- [ ] **T52** — Customizar `Dockerfile` multi-stage
- [ ] **T53** — Criar `docker-compose.yml`
- [ ] **T54** — Criar pipeline CI/CD com GitHub Actions

---

## 🏁 Fase 11 · Testes Unitários e Benchmarks

- [ ] **T61** — Testes unitários (JWT, Bcrypt, Lock, Strategy)
- [ ] **T62** — Testes unitários (Handlers) usando mocks do Repository/Stores (T03)
- [ ] **T63** — Teste E2E (Registro -> Auth -> Compra)
- [ ] **T66** — ⚡ Criar Benchmarks de Performance no Go
